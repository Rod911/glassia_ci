<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-29 19:34:04 --> 404 Page Not Found: Home/bill_view
ERROR - 2021-09-29 19:35:37 --> 404 Page Not Found: Home/bill_view
ERROR - 2021-09-29 19:42:42 --> Severity: Notice --> Undefined variable: particulars_items D:\xampp74\htdocs\glassia_ci\application\views\bill.php 155
ERROR - 2021-09-29 19:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp74\htdocs\glassia_ci\application\views\bill.php 155
ERROR - 2021-09-29 19:42:42 --> Severity: Notice --> Undefined variable: tax_type D:\xampp74\htdocs\glassia_ci\application\views\bill.php 193
ERROR - 2021-09-29 19:42:42 --> Severity: Notice --> Undefined variable: tax_type D:\xampp74\htdocs\glassia_ci\application\views\bill.php 215
ERROR - 2021-09-29 19:42:42 --> Severity: Notice --> Undefined variable: bill_total D:\xampp74\htdocs\glassia_ci\application\views\bill.php 232
ERROR - 2021-09-29 19:42:42 --> Severity: Notice --> Undefined variable: bill_total D:\xampp74\htdocs\glassia_ci\application\views\bill.php 237
ERROR - 2021-09-29 19:51:12 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp74\htdocs\glassia_ci\application\views\bill.php 55
ERROR - 2021-09-29 19:51:12 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp74\htdocs\glassia_ci\application\views\bill.php 78
ERROR - 2021-09-29 19:51:12 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp74\htdocs\glassia_ci\application\views\bill.php 87
ERROR - 2021-09-29 19:51:12 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp74\htdocs\glassia_ci\application\views\bill.php 101
ERROR - 2021-09-29 19:51:12 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp74\htdocs\glassia_ci\application\views\bill.php 125
ERROR - 2021-09-29 19:51:12 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp74\htdocs\glassia_ci\application\views\bill.php 126
ERROR - 2021-09-29 19:51:12 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp74\htdocs\glassia_ci\application\views\bill.php 131
ERROR - 2021-09-29 19:51:12 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp74\htdocs\glassia_ci\application\views\bill.php 132
ERROR - 2021-09-29 19:51:12 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp74\htdocs\glassia_ci\application\views\bill.php 134
ERROR - 2021-09-29 19:51:12 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp74\htdocs\glassia_ci\application\views\bill.php 193
ERROR - 2021-09-29 19:51:12 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp74\htdocs\glassia_ci\application\views\bill.php 215
ERROR - 2021-09-29 19:51:12 --> Severity: Notice --> Undefined variable: bill_total D:\xampp74\htdocs\glassia_ci\application\views\bill.php 232
ERROR - 2021-09-29 19:51:12 --> Severity: Notice --> Undefined variable: bill_total D:\xampp74\htdocs\glassia_ci\application\views\bill.php 237
ERROR - 2021-09-29 19:51:12 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp74\htdocs\glassia_ci\application\views\bill.php 247
ERROR - 2021-09-29 19:55:52 --> Severity: Notice --> Undefined index: invoice_total D:\xampp74\htdocs\glassia_ci\application\controllers\Home.php 44
ERROR - 2021-09-29 20:05:48 --> Severity: Notice --> A non well formed numeric value encountered D:\xampp74\htdocs\glassia_ci\application\views\form.php 31
ERROR - 2021-09-29 20:15:55 --> Severity: Notice --> Undefined offset: 2 D:\xampp74\htdocs\glassia_ci\application\views\form.php 92
ERROR - 2021-09-29 20:23:57 --> Severity: Notice --> Undefined index: invoice_total D:\xampp74\htdocs\glassia_ci\application\controllers\Home.php 48
ERROR - 2021-09-29 20:45:18 --> 404 Page Not Found: Assets/js
ERROR - 2021-09-29 20:45:18 --> 404 Page Not Found: Assets/js
ERROR - 2021-09-29 20:45:19 --> 404 Page Not Found: Assets/js
ERROR - 2021-09-29 20:45:20 --> 404 Page Not Found: Assets/js
ERROR - 2021-09-29 20:45:57 --> Severity: error --> Exception: Unable to locate the model you have specified: AdminModel D:\xampp74\htdocs\glassia_ci\system\core\Loader.php 348
ERROR - 2021-09-29 20:57:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-09-29 20:57:15 --> 404 Page Not Found: Assets/bootstrap
